﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerRun : MonoBehaviour
{
    Rigidbody2D rigid;
    public float jump;
    public float jumpSpeed;
    
    private Vector3 direction = Vector3.up;

    public GameObject gameover = null;
    

    void Start()
    {
        rigid= GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        Jump();
    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("jump");
            Rigidbody2D rigid = transform.GetComponent<Rigidbody2D>();
            

            if (rigid.velocity.y == 0)
            {

                rigid.AddForce(Vector3.up * 400);

            }
            
        }

        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Mob"))
        {
            Destroy(this.gameObject);
       
            gameover.SetActive(true);
        }
    }

        }
